README 

QUESTION 1 :
Inside the main directory :

TERMINAL COMMAND : sh Q1.sh <path to data> <plotname>          
[runs the preprocessing scripts and executes the main program which uses the separately stored processed data (inside Q1 directory) and generates plotname.png graph in the main directory or the specified path

There will be an extra .png file with the name 'extra_ignore_.png' please ignore this]

TERMINAL COMMAND : python3 Q1/preprocessing.py <path to data> gspan
[creates the preprocessed code for running gspan algorithm]

TERMINAL COMMAND : python3 Q1/preprocessing.py <path to data> fsg
[creates the preprocessed code for running fsg algorithm]

TERMINAL COMMAND : python3 Q1/preprocessing.py <path to data> gaston
[creates the preprocessed code for running gaston algorithm]

QUESTION 2 :
Inside the main directory :

TERMINAL COMMAND : sh Q2.sh <path to data> <plotname>
[runs complete execution and generates plotname.png graph in the main directory or the specified path]

There are no preprocessing scripts in this part of the question