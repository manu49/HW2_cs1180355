#!/bin/bash
data=$1
plotname=$2
out_file="$plotname.png"

python Q1/preprocessing.py $data gspan
python Q1/preprocessing.py $data fsg
python Q1/preprocessing.py $data gaston
timeout 40m python Q1/q1.py $data $plotname
python Q1/q1_alt.py $plotname
