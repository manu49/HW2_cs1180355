// subgraphiso.cpp
// Siegfried Nijssen, snijssen@liacs.nl, jul 2004.
#include "subgraphiso.h"

SubGraphIso::SubGraphIso()
{
}


SubGraphIso::~SubGraphIso()
{
}


