import matplotlib.pyplot as plt
import time
import os
import sys
out_file = sys.argv[2] + ".png"
input_file = sys.argv[1]




