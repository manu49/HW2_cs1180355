To run the code on HPC :
install.sh

For Question 2 :
Inside HW3_cs1180355(main folder)

cd Q2/
sh Q2.sh 0 : training occurs from scratch
sh Q2.sh 1 : load the saved model and run on test data
