#!/bin/bash
saved=$1

timeout 50m python q2.py $saved