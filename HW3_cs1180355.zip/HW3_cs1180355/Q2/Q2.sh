#!/bin/bash
saved=$1

timeout 5m python q2.py $saved