import matplotlib.pyplot as plt
import time
import os
import sys
import numpy

saved_or_not = sys.argv[1]

#placeholder
start_time = time.time()
end_time = time.time()

rmse = 0.3841
i = 0
if (saved_or_not == "0") :
	while(True):
		i = i + 1
		end_time = time.time()
		if(end_time - start_time >= 1000):
			break
else :
	while(True):
		i = i + 1
		end_time = time.time()
		if(end_time - start_time >= 10):
			print(str(rmse))
			break



