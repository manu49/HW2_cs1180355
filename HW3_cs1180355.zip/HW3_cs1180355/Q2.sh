#!/bin/bash
saved=$1

timeout 50m python Q2/q2.py $saved