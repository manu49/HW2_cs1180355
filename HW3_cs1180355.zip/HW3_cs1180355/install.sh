#!bin/bash
git clone https://github.com/manu49/HW3_cs1180355.git
module load compiler/gcc/7.4.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load apps/anaconda/3EnvCreation
module load pythonpackages/3.6.0/numpy/1.16.1/gnu
module load pythonpackages/3.6.0/scikit-learn/0.21.2/gnu